import React, { useContext } from 'react';
import './Productdisplay.css';
import star_icon from "../assest/star.jpg";
import star_dull_icon from "../assest/dstar.webp";
import { HomeContext } from '../../context/HomeContext';

const Productdisplay = ({ product }) => {
  const { addToCart } = useContext(HomeContext); // Call useContext unconditionally

  if (!product) {
    return null;
  }

  return (
    <div className='productdisplay'>
      <div className="productdisplay-left">
        {/* <div className="productdisplay-img-list">
          <img src={product.Image} alt=""/>
          <img src={product.Image} alt=""/>
          <img src={product.Image} alt=""/>
          <img src={product.Image} alt=""/>
        </div> */}
        <div className="productdisplay-img">
          <img className='productdisplay-main-img' src={product.Image} alt="" />
        </div>
      </div>
      <div className="productdisplay-right">
        <h1>{product.name}</h1>
        <div className="productdisplay-right-star">
          <img src={star_icon} alt="" />
          <img src={star_icon} alt="" />
          <img src={star_icon} alt="" />
          <img src={star_icon} alt="" />
          <img src={star_dull_icon} alt="" />
          <p>(122)</p>
        </div>
        <div className='productdisplay-right-price'>
          <div className='productdisplay-right-price-old'>${product.old_price}</div>
          <div className="productdisplay-right-price-new">${product.new_price}</div>
        </div>
        <div className="display-right-description">
          It is a captivating portrayal of vivid imagination and expressive creativity. Rendered with masterful skill and profound insight, this artwork invites viewers into a world of enchantment and wonder.
        </div>
        <button className='productdisplay-right-button' onClick={() => { addToCart(product.id) }}>ADD TO CART</button>
      </div>
    </div>
  );
}

export default Productdisplay;
