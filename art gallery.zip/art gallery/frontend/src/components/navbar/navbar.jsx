// navbar.jsx
import React, { useContext, useState } from 'react';
import { Link } from 'react-router-dom'; // Import Link component
import './navbar.css';
import logo from '../assest/logo.png';
import cart from '../assest/cart.svg';
import { HomeContext } from '../../context/HomeContext';

const Navbar = () => {
    const [menu, setMenu] = useState("Home");
    const {getTotalCartItems}=useContext(HomeContext);
    return (
        <div className='navbar'>
            <div className='nav-logo'>
                <img src={logo} alt=""/>
            </div>
            <ul className='nav-menu'>
                <li onClick={() => {setMenu("Home")}}>
                    <Link  style={{textDecoration: 'none'}} to='/'>Home</Link>
                    {menu==="Home" ? <hr/> : <></>}
                </li>
                <li onClick={() => {setMenu("Collection")}}>
                    <Link style={{textDecoration: 'none'}} to='/collection'>Collection</Link>
                    {menu==="Collection" ? <hr/> : <></>}
                </li>
            </ul>
            <div className='nav-login-cart'>
                <Link to='/login'><button>Login</button></Link>
                <Link to='/cart'><img src={cart} alt=""/></Link>
                <div className='nav-cart-count'>{getTotalCartItems()}</div>
            </div>
        </div>
    );
}

export default Navbar;
