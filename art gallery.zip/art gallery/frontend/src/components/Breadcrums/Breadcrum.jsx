import React from 'react'
import './Breadcrum.css'
import arrow_icon from '../assest/arrow.jpg'

const Breadcrum = (props) => {
                    const{product}=props;
  return (
                    <div className='breadcrum'>
                    Home <img src={arrow_icon} alt="" />Collection<img src={arrow_icon} alt="" />{product.category}<img src={arrow_icon} alt="" />{product.name}
                        </div>
  )
}

export default Breadcrum
// import React from 'react'
// import './breadcrum.css'
// import arrow_icon from '../assest/arrow.jpg'

// const Breadcrum = (props) => {
//                     const{product}=props;
//   return (
//     <div className='breadcrum'>
// Home <img src={arrow_icon} alt="" />Collection<img src={arrow_icon} alt="" />{product.category}<img src={arrow_icon} alt="" />{product.name}
//     </div>
//   )
// }

// export default Breadcrum 