import p1_img from "./l4.jpg";
import p2_img from "./l5.jpg";
import p3_img from "./l6.jpeg";
import p4_img from "./t1.jpeg";
import p5_img from "./36.jpeg";
import p6_img from "./39.jpg";
import p7_img from "./11.jpg";
import p8_img from "./cat-img-3.jpeg";
import p9_img from "./9.jpg";
import p10_img from "./37.jpg";
import p11_img from "./39.jpg";
import p12_img from "./g1.jpeg";
import p13_img from "./39.jpg";
import p14_img from "./g2.jpg";
import p15_img from "./21.jpg";
import p16_img from "./g6.jpg";
import p17_img from "./33.jpeg";
import p18_img from "./p1.jpg";
import p19_img from "./4.jpg";
import p20_img from "./7.jpg";


let data = [
  {
    id: 1,
    name: "The beauty of art",
    category: "Pastels",
    Image: p1_img, // Use the imported image directly
    old_price: 8000,
    new_price: 6000,
  },
  {
    id: 2,
    name: "Fitoor Art",
    category: "Tempera",
    Image: p2_img,
    old_price: 9000,    
    new_price: 6000,        
  },
  {
    id: 3,
    name: "Lord of Ring",
    category: "oil",
    Image: p3_img,
    old_price: 7000,    
    new_price: 6000,        
  },
  {
    id: 4,
    name: "The Life",
    category: "Fresco",
    Image: p4_img,
    old_price: 7000,    
    new_price: 6000,        
  },
  {
                    id: 5,
                    name: "Thalapthi",
                    category: "Pencil Art",
                    Image: p5_img,
                    old_price: 8500,    
                    new_price: 5500,        
                  },
                  {
                    id: 6,
                    name: "River Bank",
                    category: "Fresco",
                    Image: p6_img,
                    old_price: 9000,    
                    new_price: 6500,        
                  },
                  {
                    id: 7,
                    name: "Peacock",
                    category: "Fresco",
                    Image: p7_img,
                    old_price: 8000,    
                    new_price: 6300,        
                  },
                  {
                    id: 8,
                    name: "Perfect View",
                    category: "Fresco",
                    Image: p8_img,
                    old_price: 10000,    
                    new_price: 8500,        
                  },
                  {
                    id: 9,
                    name: "Pirate Girl",
                    category: "Fresco",
                    Image: p9_img,
                    old_price: 8300,    
                    new_price: 7200,        
                  },
                  {
                    id: 10,
                    name: "Baby",
                    category: "Fresco",
                    Image: p10_img,
                    old_price: 3384,
                    new_price: 2233,        
                  },
                  {
                    id: 11,
                    name: "River Bank",
                    category: "Fresco",
                    Image: p11_img,
                    old_price: 5787,    
                    new_price: 4433,        
                  },
                  {
                    id: 12,
                    name: "Ganapathi",
                    category: "Fresco",
                    Image: p12_img,
                    old_price: 7000,    
                    new_price: 2345,        
                  },
                  {
                    id: 13,
                    name: "Beauty of River",
                    category: "Fresco",
                    Image: p13_img,
                    old_price: 8743,    
                    new_price: 4387,        
                  },
                  {
                    id: 14,
                    name: "Vinagayar",
                    category: "Fresco",
                    Image: p14_img,
                    old_price: 5874,    
                    new_price: 3455,        
                  },
                  {
                    id: 15,
                    name: "Monolisa",
                    category: "Fresco",
                    Image: p15_img,
                    old_price: 8763,    
                    new_price: 4567,        
                  },
                  {
                    id: 16,
                    name: "Yellow Vinayagar",
                    category: "Fresco",
                    Image: p16_img,
                    old_price: 8734,    
                    new_price: 6000,        
                  },
                  {
                    id: 17,
                    name: "Pot",
                    category: "Fresco",
                    Image: p17_img,
                    old_price: 9873,    
                    new_price: 5766,        
                  },
                  {
                    id: 18,
                    name: "River Boat",
                    category: "Fresco",
                    Image: p18_img,
                    old_price: 9864,    
                    new_price: 4578,        
                  },
                  {
                    id: 19,
                    name: "Perfect View",
                    category: "Fresco",
                    Image: p19_img,
                    old_price: 3845,    
                    new_price: 2345,        
                  },
                  {
                    id: 20,
                    name: "Humming bird",
                    category: "Fresco",
                    Image: p20_img,
                    old_price: 8763,    
                    new_price: 3455,        
                  },

];

export default data;
