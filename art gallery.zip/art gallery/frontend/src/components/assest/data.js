import p1_img from "./21.jpg";
import p2_img from "./2.jpg";
import p3_img from "./g1.jpeg";
import p4_img from "./l4.jpg";

let data = [
  {
    id: 1,
    name: "The beauty of art",
    category: "Pastels",
    Image: p1_img, // Use the imported image directly
    old_price: 8000,
    new_price: 6000,
  },
  {
    id: 2,
    name: "Fitoor Art",
    category: "Tempera",
    Image: p2_img,
    old_price: 9000,    
    new_price: 6000,        
  },
  {
    id: 3,
    name: "Lord of Ring",
    category: "oil",
    Image: p3_img,
    old_price: 7000,    
    new_price: 6000,        
  },
  {
    id: 4,
    name: "The Life",
    category: "Fresco",
    Image: p4_img,
    old_price: 7000,    
    new_price: 6000,        
  },
];

export default data;
