import p1_img from "./3.jpg";
import p2_img from "./l5.jpg";
import p3_img from "./l6.jpeg";
import p4_img from "./t1.jpeg";
import p5_img from "./43.jpg";
import p6_img from "./45.jpg";
import p7_img from "./35.jpeg";
import p8_img from "./46.jpg";

let new_collections= [
  {
    id: 1,
    name: "The beauty of art",
    category: "Pastels",
    Image: p1_img, // Use the imported image directly
    old_price: 8000,
    new_price: 6000,
  },
  {
    id: 2,
    name: "Fitoor Art",
    category: "Tempera",
    Image: p2_img,
    old_price: 8000,
    new_price: 6000,          
  },
  {
    id: 3,
    name: "Lord of Ring",
    category: "oil",
    Image: p3_img,
    old_price: 8000,
    new_price: 6000,            
  },
  {
    id: 4,
    name: "The Life",
    category: "Fresco",
    Image: p4_img,
    old_price: 8000,
    new_price: 6000,            
  },
  {
  id: 5,
    name: "The beauty of art",
    category: "Pastels",
    Image: p5_img, // Use the imported image directly
    old_price: 8000,
    new_price: 6000,
  },
  {
    id: 6,
    name: "Fitoor Art",
    category: "Tempera",
    Image: p6_img,
    old_price: 8000,
    new_price: 6000,           
  },
  {
    id: 7,
    name: "Lord of Ring",
    category: "oil",
    Image: p7_img,
    old_price: 8000,
    new_price: 6000,            
  },
  {
    id: 8,
    name: "The Life",
    category: "Fresco",
    Image: p8_img,
    old_price: 8000,
    new_price: 6000,            
  },
];

export default new_collections;
