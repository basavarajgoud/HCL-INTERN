import g1_img from "./g1.jpeg";
import g2_img from "./g2.jpg";
import g3_img from "./g3.jpg";
import g4_img from "./g4.jpg";
import g5_img from "./g5.jpg";

let new_dataset=[
                    {
                                        id: 1,
                                        name: "The beauty of art",
                                        category: "Pastels",
                                        Image: g1_img, // Use the imported image directly
                                        old_price: 8000,
                                        new_price: 6000,
                                      }  ,
                                      {
                                        id: 2,
                                        name: "The beauty of art",
                                        category: "Pastels",
                                        Image: g2_img, // Use the imported image directly
                                        old_price: 8000,
                                        new_price: 6000,
                                      }  ,
                                      {
                                        id: 3,
                                        name: "The beauty of art",
                                        category: "Pastels",
                                        Image: g3_img, // Use the imported image directly
                                        old_price: 8000,
                                        new_price: 6000,
                                      } ,
                                      {
                                        id: 4,
                                        name: "The beauty of art",
                                        category: "Pastels",
                                        Image: g4_img, // Use the imported image directly
                                        old_price: 8000,
                                        new_price: 6000,
                                      },
                                      {
                                        id: 5,
                                        name: "The beauty of art",
                                        category: "Pastels",
                                        Image:g5_img , // Use the imported image directly
                                        old_price: 8000,
                                        new_price: 6000,
                                      }  ,     
                                        
                    
]
export default new_dataset;

