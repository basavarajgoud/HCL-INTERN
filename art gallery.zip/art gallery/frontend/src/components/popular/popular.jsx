import React from 'react';
import './popular.css';
import data from '../assest/data.js';
import Item from '../items/item.jsx'; // Corrected import path

const Popular = () => {
  return (
    <div className='popular'>
      <h1>POPULAR ARTS</h1>
      <hr />
      <div className="popular-item">
        {data.map((item, i) => (
          <Item key={i} id={item.id} name={item.name} category={item.category} Image={item.Image} old_price={item.old_price} new_price={item.new_price} />
        ))}
      </div>
    </div>
  );
};

export default Popular; // Changed to default export
