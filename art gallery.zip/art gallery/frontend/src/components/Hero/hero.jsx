// hero.jsx
import React from 'react';
import './hero.css';
import hero_img from '../assest/cat-img-3.jpeg';

const Hero = () => {
  return (
    <div className='hero'>
      <div className='hero-left'>
        <h2>
          The Language of the Soul, Spoken Through Colors and Shapes.</h2>
          <br />
          <p>Welcome to our Art Piece, where every stroke and sculpture narrates
          the endless stories of human creativity and emotion.</p>
        
      </div>
      <div className='hero-right'>
        <img src={hero_img} alt="Artwork" />
      </div>
    </div>
  );
}

export default Hero;
