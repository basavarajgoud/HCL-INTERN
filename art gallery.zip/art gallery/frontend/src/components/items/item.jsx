import React from 'react';
import { Link } from 'react-router-dom';
import './item.css';


const item = (props) => {
  return (
    <div className='item'>
      <Link to= {`product/${props.id}`}><img onClick={window.scrollTo(0,0)} src={props.Image} alt=""/></Link>
      <p>{props.name}</p>
      <div className="item-prices">
        <div className="item-price-new">
          ${props.new_price}
        </div>
        <div className="item-price-old">
          ${props.old_price}
        </div>
      </div>

    </div>
  )
}

export default item

// const Item = (props) => {
//   const { id, Image, name, category,old_price,new_price } = props;

//   return (
//     <div className='item'>
//       <Link to={`/product/${id}`}>
//         <img src={Image} alt={name} />
//       </Link>
//       <p>{name}</p>
//       <div className='item-category'>
//         Category: {category}
//       </div>
//       <div className='item-prices'>
//       <div className='item-price-old'>
//           Old_Price: $ {props.old_price}
//         </div>
//         <div className='item-price-new'>
//         New_Price: $ {new_price}
//         </div>
        
//       </div>
//     </div>
//   );
// };

// export default Item;
