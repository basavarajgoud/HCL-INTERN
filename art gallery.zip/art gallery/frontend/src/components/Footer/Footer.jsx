import React from 'react'
import './Footer.css'
import footer_logo from '../assest/logo.png'
import instagram_logo from '../assest/instagram.svg'
import pinterest_logo from '../assest/pinterest.svg'
import whatsapp_logo from '../assest/whatsapp.svg'

const Footer = () => {
  return (
    <div className='footer'>
<div className='footer-logo'>
                    <img src={footer_logo} alt="" />
                    
 
</div>
<ul className='footer-links'>
                    <li>Company</li>
                    <li>Product</li>

                    <li>Office</li>
                      <li>About</li>
                    <li>Contact</li>


</ul>
<div className='footer-social-icon'>
                    <div className='footer-icons-container'>
                                        <img src={instagram_logo} alt="" />

                    </div>
                    <div className='footer-icons-container'>
                                        <img src={pinterest_logo} alt="" />

                    </div>
                    <div className='footer-icons-container'>
                                        <img src={whatsapp_logo} alt="" />

                    </div>

</div>
<div className='footer-copyright'>
<hr />
<p>Copyright @ 2024 All Right Reserved.</p>

</div>
    </div>
  )
}

export default Footer