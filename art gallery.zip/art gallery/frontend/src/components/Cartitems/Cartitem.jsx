import React, { useContext } from 'react';
import './Cartitem.css';
import { HomeContext } from '../../context/HomeContext';
import remove_icon from '../assest/remove_icon.png';

const CartItem = () => {
    const { getTotalCartAmount, data, cartItems, addToCart, removeFromCart } = useContext(HomeContext);

    const handleAddToCart = (itemId) => {
        addToCart(itemId);
    };

    const handleRemoveFromCart = (itemId) => {
        removeFromCart(itemId);
    };

    return (
        <div className="cartitems">
            <div className="cartitems-format-main">
                <p>Products</p>
                <p>Title</p>
                <p>Price</p>
                <p>Quantity</p>
                <p>Total</p>
                <p>Remove</p>
            </div>
            <hr />
            {data.map((e) => {
                if (cartItems[e.id] > 0) {
                    return (
                        <div key={e.id}>
                            <div className="cartitems-format">
                                <img src={e.Image} alt={e.name} className='cartitems-product-image' /> {/* Change className to 'cartitems-product-image' */}
                                <p>{e.name}</p>
                                <p>${e.new_price}</p>
                                <div>
                                    <button onClick={() => handleRemoveFromCart(e.id)}>-</button>
                                    <span>{cartItems[e.id]}</span>
                                    <button onClick={() => handleAddToCart(e.id)}>+</button>
                                </div>
                                <p>${e.new_price * cartItems[e.id]}</p>
                                <img
                                    src={remove_icon}
                                    onClick={() => handleRemoveFromCart(e.id)}
                                    alt="Remove"
                                    className="remove-icon"
                                />
                            </div>
                            <hr />
                        </div>
                    );
                } else {
                    return null;
                }
            })}
            <div className="cartitems-total">
                <h1>Cart Totals</h1>
                <div className="cartitems-total-item">
                    <p>Subtotal</p>
                    <p>${getTotalCartAmount()}</p>
                </div>
                <hr />
                <div className="cartitems-total-item">
                    <p>Shipping Fee</p>
                    <p>Free</p>
                </div>
                <hr />
                <div className="cartitems-total-item">
                    <h3>Total</h3>
                    <h3>${getTotalCartAmount()}</h3>
                </div>
                <button>PROCEED TO CHECKOUT</button>
            </div>
            <div className="cartitems-promocode">
                <p>If you have a promo code, enter it here</p>
                <div className="cartitems-promobox">
                    <input type="text" placeholder='promo code'/>
                    <button>Submit</button>
                </div>
            </div>
        </div>
    );
}

export default CartItem;
