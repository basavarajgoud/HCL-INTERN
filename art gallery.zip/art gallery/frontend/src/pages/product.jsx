import React, { useContext } from 'react';
import { HomeContext } from '../context/HomeContext.jsx';
import { useParams } from 'react-router-dom';

import Productdisplay from '../components/ProductDisplay/Productdisplay.jsx';
import Breadcrum from '../components/Breadcrums/Breadcrum.jsx';
import RelatedProduct from '../components/RelatedProducts/RelatedProduct.jsx';





// Corrected the import path and component name

const Product = () => {
  const {data } = useContext(HomeContext);
  const { productId } = useParams();
  const product = data.find((e) => e.id === Number(productId));
  return (
    <div>
     <Breadcrum product={product}/>
      <Productdisplay product={product}/>
      <RelatedProduct/>
      
    </div>
  );
}

export default Product;





