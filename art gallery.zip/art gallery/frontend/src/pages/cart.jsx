import React from 'react';
import CartItem from '../components/Cartitems/Cartitem'; // Import the CartItem component

const Cart = () => {
  return (
    <div>
      <CartItem/> {/* Render the CartItem component */}
    </div>
  )
}

export default Cart;