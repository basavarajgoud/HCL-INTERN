// Home.jsx
import React from 'react';
import Hero from '../components/Hero/hero.jsx';
import Popular from '../components/popular/popular.jsx'; // Corrected import
import Offers from '../components/offers/offers.jsx';
import NewCollections from '../components/NewCollections/NewCollections.jsx';
import NewsLetter from '../components/NewsLetter/NewsLetter.jsx';


const Home = () => {
  return (
    <div>
      <Hero /> 
      <Popular />
      <Offers/>
      <NewCollections />
      <NewsLetter />
    </div>
  );
};

export default Home;
