// HomeCategory.jsx
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import './css/HomeCategory.css';
import { HomeContext } from '../context/HomeContext';
import Item from '../components/items/item';

export const HomeCategory = (props) => {
  const { data } = useContext(HomeContext);

  return (
    <div className='shop-category'>
      <img src={props.banner} alt="" /> 
      <div className="shopcategory-products">
        {/* Wrap each image with a Link to the Productdisplay page */}
        {data.map((item) => (
          <Link key={item.id} to={`/product/${item.id}`}>
            <Item
              id={item.id}
              name={item.name}
              category={item.category}
              Image={item.Image}
              old_price={item.old_price}
              new_price={item.new_price}
            />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default HomeCategory;
