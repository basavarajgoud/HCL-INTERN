import React from 'react';
import './App.css';
import Navbar from './components/navbar/navbar';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import HomeCategory from './pages/HomeCategory'; // Import HomeCategory component
import Cart from './pages/cart.jsx'; // Import the Cart component
import Logins from './pages/Logins.jsx';
import Footer from './components/Footer/Footer.jsx';
import Collection_banner from './components/assest/banner.jpg';
import Product from './pages/product.jsx';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/collection' element={<HomeCategory banner={Collection_banner} category="Collection" />} /> {/* Route for HomeCategory */}
          <Route path='/product/:productId' element={<Product />} />
          <Route path='/cart' element={<Cart />} /> {/* Route for the Cart component */}
          <Route path='/login' element={<Logins />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
